import UIKit

func stablefordPointsCalculator(handicap: Int, par: Int, strokeIndex: Int, gross: Int) -> Int {
    
    var points: Int = 0
    var net: Int = 0
    
    if handicap <= 18 {
        if handicap - strokeIndex >= 0 {
            net = (gross - 1)
        }
        else {
            net = gross
        }
    }

    if handicap > 18 {
        if (handicap - 18) - strokeIndex >= 0 {
            net = (gross - 2)
        }
        else {
            net = (gross - 1)
        }
    }


    switch net {
    case _ where net >= par + 2:
        points = 0
        return points

    case _ where net == par + 1:
        points = 1
        return points

    case _ where net == par:
        points = 2
        return points

    case _ where net == par - 1:
        points = 3
        return points

    case _ where net == par - 2:
        points = 4
        return points

    case _ where net == par - 3:
        points = 5
        return points

    case _ where net == par - 4:
        points = 6
        return points

    default:
        points = 0
        return points
    }
}

stablefordPointsCalculator(handicap: 10, par: 5, strokeIndex: 1, gross: 6)
