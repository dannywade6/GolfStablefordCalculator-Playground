import UIKit

var handicap: Int = 1
var par: Int = 4
var strokeIndex: Int = 3
var net: Int = 0
var gross: Int = 5
var points: Int = 0


if handicap <= 18 {
    if handicap - strokeIndex >= 0 {
        net = (gross - 1)
    }
    else {
        net = gross
    }
}

if handicap > 18 {
    if (handicap - 18) - strokeIndex >= 0 {
        net = (gross - 2)
    }
    else {
        net = (gross - 1)
    }
}


switch net {
case _ where net >= par + 2:
    points = 0

case _ where net == par + 1:
    points = 1

case _ where net == par:
    points = 2

case _ where net == par - 1:
    points = 3

case _ where net == par - 2:
    points = 4

case _ where net == par - 3:
    points = 5

case _ where net == par - 4:
    points = 6

default:
    points = 0
}


print("Your Handicap is: \(handicap).")
print("On this Par \(par), with the Stroke Index of \(strokeIndex):")
if points == 1 {
    print("You shot \(gross), and scored \(points) point.")
} else {
    print("You shot \(gross), and scored \(points) points.")
}
