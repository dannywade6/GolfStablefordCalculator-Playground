import UIKit

var handicap: Int = 3
var par: Int = 3
var strokeIndex: Int = 5
var net: Int = 0
var gross: Int = 4
var points: Int = 0


if handicap >= 18 {
    if handicap - strokeIndex >= 0 {
        net = gross - 1
    }
} else {
    net = gross
}

if net >= par + 2 {
    points = 0
}

if net == par + 1 {
    points = 1
}

if net == par {
    points = 2
}

if net == par - 1 {
    points = 3
}

if net == par - 2 {
    points = 4
}

if net == par - 3 {
    points = 5
}

if net == par - 4 {
    points = 6
}

print("Your net score is: \(net), you have shot \(points) points")


